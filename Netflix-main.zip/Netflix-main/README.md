

#  Netflix-clone

This is a Neflix-clone landing page

## Screenshot

<p align="center">
  <img width="auto" src="https://user-images.githubusercontent.com/74991230/174607534-d2f92e16-bc60-4694-a6a1-dcdaf4b73d02.png" alt="Netflix clone screenshot" />
</p>


## Built With

 - HTML5
 - CSS
 - SASS
 - BOOTSTRAP
 
